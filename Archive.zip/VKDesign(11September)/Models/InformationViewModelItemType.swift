//
//  InformationViewModelItemType.swift
//  VKDesign(11September)
//
//  Created by BLVCK on 25/09/2017.
//  Copyright © 2017 blvvvck production. All rights reserved.
//

import Foundation

enum InformationViewModelItemType {
    case status
    case mainInfo
    case contacts
    case carier
    case education
    case gifts
    case moreInfo
}
